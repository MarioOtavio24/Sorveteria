Use sorveteria;
SELECT * FROM Pedido;
SELECT * FROM ItemPedido;